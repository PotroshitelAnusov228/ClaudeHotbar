package com.example.squarehotbar;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.LiteralText;
import org.lwjgl.glfw.GLFW;

public class HotbarConfigScreen extends Screen {
    private ButtonWidget stepButton;

    public HotbarConfigScreen() {
        super(new LiteralText("Настройка хотбара"));
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    private static LiteralText t(String s) {
        return new LiteralText(s);
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int y0 = this.height / 2 - 90;

        // размер
        this.addButton(new ButtonWidget(cx - 50, y0 + 12, 20, 20, t("-"), b -> {
            HotbarConfig.cellSize -= HotbarConfig.step;
            HotbarConfig.clamp();
        }));
        this.addButton(new ButtonWidget(cx + 30, y0 + 12, 20, 20, t("+"), b -> {
            HotbarConfig.cellSize += HotbarConfig.step;
            HotbarConfig.clamp();
        }));

        // перемещение (крестовина)
        this.addButton(new ButtonWidget(cx - 10, y0 + 52, 20, 20, t("^"), b -> HotbarConfig.offsetY -= HotbarConfig.step));
        this.addButton(new ButtonWidget(cx - 32, y0 + 74, 20, 20, t("<"), b -> HotbarConfig.offsetX -= HotbarConfig.step));
        this.addButton(new ButtonWidget(cx + 12, y0 + 74, 20, 20, t(">"), b -> HotbarConfig.offsetX += HotbarConfig.step));
        this.addButton(new ButtonWidget(cx - 10, y0 + 96, 20, 20, t("v"), b -> HotbarConfig.offsetY += HotbarConfig.step));

        // шаг
        this.stepButton = this.addButton(new ButtonWidget(cx - 60, y0 + 122, 120, 20, t(stepLabel()), b -> {
            HotbarConfig.step = HotbarConfig.step == 1 ? 5 : (HotbarConfig.step == 5 ? 10 : 1);
            b.setMessage(t(stepLabel()));
        }));

        this.addButton(new ButtonWidget(cx - 60, y0 + 146, 120, 20, t("Сбросить"), b -> HotbarConfig.reset()));
        this.addButton(new ButtonWidget(cx - 60, y0 + 170, 120, 20, t("Готово"), b -> this.onClose()));
    }

    private static String stepLabel() {
        return "Шаг: " + HotbarConfig.step + " px";
    }

    @Override
    public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        // фон не затемняем, чтобы хотбар был виден вживую
        int cx = this.width / 2;
        int y0 = this.height / 2 - 90;

        center(matrices, "Настройка хотбара (H - закрыть)", cx, y0 - 12);
        center(matrices, "Размер ячейки: " + HotbarConfig.cellSize + " px", cx, y0 + 2);
        center(matrices, "X: " + HotbarConfig.offsetX + "   Y: " + HotbarConfig.offsetY, cx, y0 + 40);

        super.render(matrices, mouseX, mouseY, delta);
    }

    private void center(MatrixStack matrices, String s, int x, int y) {
        this.textRenderer.drawWithShadow(matrices, s, x - this.textRenderer.getWidth(s) / 2f, y, 0xFFFFFF);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_H) {
            this.onClose();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void removed() {
        HotbarConfig.save();
    }
}
