package com.example.squarehotbar.mixin;

import com.example.squarehotbar.HotbarConfig;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawableHelper;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public abstract class InGameHudMixin extends DrawableHelper {

    private static final int CELL = 20; // базовый размер ванильной ячейки
    private static final Identifier WIDGETS = new Identifier("textures/gui/widgets.png");

    @Shadow @Final private MinecraftClient client;

    @Shadow
    protected abstract void renderHotbarItem(int x, int y, float tickDelta, PlayerEntity player, ItemStack stack);

    @Inject(method = "renderHotbar", at = @At("HEAD"), cancellable = true)
    private void squarehotbar$render(float tickDelta, MatrixStack matrices, CallbackInfo ci) {
        if (!(this.client.getCameraEntity() instanceof PlayerEntity)) {
            return;
        }
        PlayerEntity player = (PlayerEntity) this.client.getCameraEntity();
        ci.cancel();

        // Все настройки заданы в реальных пикселях, переводим в GUI-единицы.
        double gs = this.client.getWindow().getScaleFactor();
        float scale = (float) (HotbarConfig.cellSize / (CELL * gs));
        float x = (float) (HotbarConfig.offsetX / gs);
        float totalGui = (float) (3.0 * HotbarConfig.cellSize / gs);
        float y = (this.client.getWindow().getScaledHeight() - totalGui) / 2.0F + (float) (HotbarConfig.offsetY / gs);

        RenderSystem.pushMatrix();
        RenderSystem.translatef(x, y, 0.0F);
        RenderSystem.scalef(scale, scale, 1.0F);
        RenderSystem.enableRescaleNormal();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();

        // 1) фон ячеек
        for (int i = 0; i < 9; i++) {
            int cx = (i % 3) * CELL;
            int cy = (i / 3) * CELL;
            fill(matrices, cx, cy, cx + CELL, cy + CELL, 0xFF8B8B8B);
            fill(matrices, cx + 1, cy + 1, cx + CELL - 1, cy + CELL - 1, 0xB0000000);
        }

        // 2) обводка выбранного слота (ванильная текстура)
        int selected = player.inventory.selectedSlot;
        if (selected >= 0 && selected < 9) {
            int sx = (selected % 3) * CELL - 2;
            int sy = (selected / 3) * CELL - 2;
            this.client.getTextureManager().bindTexture(WIDGETS);
            RenderSystem.color4f(1.0F, 1.0F, 1.0F, 1.0F);
            this.drawTexture(matrices, sx, sy, 0, 22, 24, 24);
        }

        // 3) предметы, количество, прочность
        RenderSystem.enableRescaleNormal();
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        for (int i = 0; i < 9; i++) {
            int cx = (i % 3) * CELL + 2;
            int cy = (i / 3) * CELL + 2;
            this.renderHotbarItem(cx, cy, tickDelta, player, player.inventory.getStack(i));
        }

        RenderSystem.disableRescaleNormal();
        RenderSystem.disableBlend();
        RenderSystem.popMatrix();
    }
}
